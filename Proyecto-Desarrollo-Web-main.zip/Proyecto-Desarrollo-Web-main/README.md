SpringBoot + TailwindCSS + Thymeleaf + PHP

